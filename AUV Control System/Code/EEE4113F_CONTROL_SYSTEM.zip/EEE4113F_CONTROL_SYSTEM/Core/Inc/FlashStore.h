#ifndef FLASH_STORE_H
#define FLASH_STORE_H

#include <stdint.h>
#include "stm32f4xx_hal.h"

/* Calibration data persisted in flash. Keep it small and word-aligned. */
typedef struct {
    uint32_t magic;        /* identifies a valid record           */
    float    slope;        /* corrected = slope * raw + offset_mm */
    float    offset_mm;
    uint32_t cal_count;    /* how many times calibrated (info)    */
    uint32_t crc;          /* CRC32 over the preceding fields     */
} CalRecord;

#define FLASH_STORE_MAGIC      0xCA11B4ABU   /* arbitrary identifier */

/* Sector 5 is the last sector on the F411CCU6 (256 KB chip).
   Update the linker script LENGTH to 128K so code can't land here. */
#define FLASH_STORE_SECTOR     FLASH_SECTOR_5
#define FLASH_STORE_ADDRESS    0x08020000U

/* Returns 1 if a valid record was loaded into *out, 0 otherwise. */
uint8_t FlashStore_Load(CalRecord *out);

/* Erases the sector and writes the record. Returns 1 on success. */
uint8_t FlashStore_Save(const CalRecord *rec);

#endif
