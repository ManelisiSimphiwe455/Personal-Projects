#include "FlashStore.h"
#include <stddef.h>   /* offsetof */
#include <string.h>   /* memcpy   */

/* Catch any future struct change that would break the word-aligned write. */
_Static_assert(sizeof(CalRecord) % 4 == 0,
               "CalRecord must be a multiple of 4 bytes for word writes");

/* Simple CRC32 (poly 0xEDB88320). The F4 has a hardware CRC unit but
   software is fine for a 16-byte payload only touched at boot/calibrate. */
static uint32_t crc32(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFU;
    for (uint32_t i = 0; i < len; i++)
    {
        crc ^= data[i];
        for (int b = 0; b < 8; b++)
            crc = (crc >> 1) ^ (0xEDB88320U & -(crc & 1));
    }
    return ~crc;
}

uint8_t FlashStore_Load(CalRecord *out)
{
    if (out == NULL) return 0;

    const CalRecord *flash_rec = (const CalRecord *)FLASH_STORE_ADDRESS;

    if (flash_rec->magic != FLASH_STORE_MAGIC) return 0;

    /* CRC covers everything except the CRC field itself. */
    uint32_t computed = crc32((const uint8_t *)flash_rec,
                              offsetof(CalRecord, crc));
    if (computed != flash_rec->crc) return 0;

    memcpy(out, flash_rec, sizeof(CalRecord));
    return 1;
}

uint8_t FlashStore_Save(const CalRecord *rec)
{
    if (rec == NULL) return 0;

    /* Build the record locally so we can compute the CRC over a known buffer. */
    CalRecord tmp = *rec;
    tmp.magic = FLASH_STORE_MAGIC;
    tmp.crc   = crc32((const uint8_t *)&tmp, offsetof(CalRecord, crc));

    HAL_FLASH_Unlock();

    /* Clear any leftover error flags from a previous operation. */
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP    | FLASH_FLAG_OPERR |
                           FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR|
                           FLASH_FLAG_PGSERR);

    /* Erase Sector 5 (128 KB — takes ~1-2 seconds). */
    FLASH_EraseInitTypeDef erase = {
        .TypeErase    = FLASH_TYPEERASE_SECTORS,
        .Sector       = FLASH_STORE_SECTOR,
        .NbSectors    = 1,
        .VoltageRange = FLASH_VOLTAGE_RANGE_3   /* 2.7-3.6V */
    };
    uint32_t sector_err = 0;
    if (HAL_FLASHEx_Erase(&erase, &sector_err) != HAL_OK)
    {
        HAL_FLASH_Lock();
        return 0;
    }

    /* Write the struct as 32-bit words. */
    const uint32_t *src = (const uint32_t *)&tmp;
    uint32_t addr = FLASH_STORE_ADDRESS;
    for (uint32_t i = 0; i < sizeof(CalRecord) / 4; i++)
    {
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,
                              addr + i * 4, src[i]) != HAL_OK)
        {
            HAL_FLASH_Lock();
            return 0;
        }
    }

    HAL_FLASH_Lock();
    return 1;
}
